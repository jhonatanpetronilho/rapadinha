<template>
    <BaseLayout>
        <div class="">
            <div class="">

                <div class="relative col-span-2">
                    <div v-if="setting != null && wallet != null && isLoading === false" class="flex flex-col w-full shadow-lg p-4 rounded mx-auto sm:max-w-[690px] lg:max-w-[710px]">
                        <form v-if="wallet.currency === 'USD'" action="" @submit.prevent="submitWithdrawBank">
                            <div class="flex items-center justify-between">
                               <div>
                                   <i class="mr-3 text-lg fa-regular fa-building-columns"></i>
                                   <span class="ml-3">{{ $t('BANK') }}</span>
                               </div>
                                <button @click.prevent="$router.push('/profile/wallet')" type="button" class="flex items-center justify-center pt-1 mr-3">
                                    <div>{{ wallet.currency }}</div>
                                    <div class="ml-2 mr-2">
                                        <img :src="`/assets/images/coin/`+wallet.currency+`.png`" alt="" width="32">
                                    </div>
                                    <div class="ml-2 text-sm">
                                        <i class="fa-solid fa-chevron-down"></i>
                                    </div>
                                </button>
                            </div>

                            <div class="mt-5">
                                <div class="mb-3 text-sm">
                                    <label for="">Nome do titular da conta</label>
                                    <input v-model="withdraw_deposit.name" type="text" class="input" placeholder="Digite o nome do titular da conta" required>
                                </div>

                                <div class="mt-5">
                                    <label for="message" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('Banking information') }}</label>
                                    <textarea v-model="withdraw_deposit.bank_info" id="message" cols="30" rows="10" class="input min-h-[250px]" :placeholder="$t('Enter bank information')"></textarea>
                                </div>

                                <div class="mt-4 mb-3">
                                    <div class="flex justify-between text-sm">
                                        <p>Valor ({{ setting.min_withdrawal }} ~ {{ setting.max_withdrawal }})</p>
                                        <p>Saldo: {{ state.currencyFormat(parseFloat(wallet.balance_withdrawal), wallet.currency) }}</p>
                                    </div>
                                    <div class="flex ">
                                        <input type="text"
                                               class="input"
                                               v-model="withdraw_deposit.amount"
                                               :min="setting.min_withdrawal"
                                               :max="setting.max_withdrawal"
                                               placeholder=""
                                               required>
                                        <div class="flex items-center pr-1">
                                            <div class="inline-flex shadow-sm" role="group">
                                                <button @click.prevent="setMaxAmount" type="button" class="px-4 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-2 focus:ring-blue-700 focus:text-blue-700 dark:text-white dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-blue-500 dark:focus:text-white">
                                                    max
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between mt-2 text-sm">
                                        <p>{{ $t('Available') }}: {{ state.currencyFormat(parseFloat(wallet.balance_withdrawal), wallet.currency) }} {{ wallet.currency }}</p>
                                        <p>{{ $t('Balance Rollback') }}: {{ state.currencyFormat(parseFloat(wallet.balance_bonus), wallet.currency) }} {{ wallet.currency }}</p>
                                    </div>
                                </div>

                                <div class="mt-5 mb-3">
                                    <div class="flex items-center mb-4">
                                        <input id="accept_terms_checkbox" v-model="withdraw_deposit.accept_terms"
                                               type="checkbox"
                                               value=""
                                               class="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-500 dark:focus:ring-green-600 dark:ring-offset-gray-800 focus:ring-2">
                                        <label for="accept_terms_checkbox" class="text-sm font-medium text-gray-900 ms-2 dark:text-gray-400">
                                            {{ $t('I accept the transfer terms') }}
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="flex items-center justify-center w-full mt-5">
                                <button type="submit" class="w-full ui-button-blue">
                                    <span class="text-sm font-semibold uppercase">{{ $t('Request withdrawal') }}</span>
                                </button>
                            </div>
                        </form>

                        <form style="background-color: #212425;border-radius: 8px;padding: 20px" v-if="wallet.currency === 'BRL'" action="" @submit.prevent="submitWithdraw">
                            <div class="flex items-center justify-between">
                              <div class="image-container">
    <!-- Logo -->
    <img :src="`/storage/`+setting.software_logo_black2" alt="" class="block md:rounded-t-lg logo-image" />

   <!-- Texto acima da imagem do Pix (Solicitar Saque) -->
<div class="mt-4 text-container" style="text-align: left;">
    <span class="text-white text-bold" style="font-weight: bold; color: white; font-size: 18px;">
        <i class="fas fa-arrow-left" style="margin-right: 10px;"></i> Solicitar Saque
    </span>
</div>

<!-- Texto abaixo (Retire saldo da sua conta) -->
<div class="mt-2 text-container" style="position: relative; left: -69px;">
    <span class="text-light text-gray" style="color: #6e6e6f; font-size: 14px;">
        Retire saldo da sua conta
    </span>
</div>



    <!-- Imagem do Pix -->
    <img :src="`/assets/images/pix.png`" alt="" class="pix-image" width="100" style="border: 1px solid #a7dc0d; padding: 5px; border-radius: 8px;">
</div>




                    </div>

                            <div class="mt-5">
                                <div class="mb-3 dark:text-gray-400">
                                    <label style="color: var(--title-color);" for="">Nome do titular da conta</label>
                                    <input style="background-color: #323637;" v-model="withdraw.name" type="text" class="input" placeholder="Digite o nome do titular da conta" required>
                                </div>



                                <div class="mb-3">
    <div class="mb-3 dark:text-gray-400">
        <label style="color: var(--title-color);" for="">Valor do saque:</label>

        <!-- Flex container para o input e os elementos ao lado -->
        <div class="flex items-center">
            <input
                style="background-color: #323637;"
                type="text"
                class="flex-1 input"
                v-model="withdraw.amount"
                :min="setting.min_withdrawal"
                :max="setting.max_withdrawal"
                placeholder=""
                required
            >

            <!-- Imagem da Bandeira do Brasil com borda redonda ao lado do input -->
            <div class="flex items-center pl-2">
                <img src="/public/assets/images/BRA.png" alt="Bandeira do Brasil" class="w-8 h-8 rounded-full" />
                <span class="ml-2 text-white">BRL</span>
            </div>
        </div>
    </div>

    <!-- Exibição do valor disponível -->
    <div class="flex justify-between mt-2">
        <p style="color: var(--title-color);">
            {{ $t('Available') }}:
            <span style="color: #a7dc0d; font-weight: bold;">
                {{ state.currencyFormat(parseFloat(wallet.balance_withdrawal), wallet.currency) }} {{ wallet.currency }}
            </span>
        </p>
    </div>
</div>

                                <div class="mb-3 dark:text-gray-400">
                                    <label style="color: var(--title-color);" for="">Tipo de Chave</label>
                                    <select style="background-color: #323637;" v-model="withdraw.pix_type" name="type_document" class="input" required>
                                        <option value="">Selecione uma chave</option>
                                        <option value="document">CPF/CNPJ</option>
                                    </select>
                                </div>
                                <div class="mb-3 dark:text-gray-400">
                                    <label style="color: var(--title-color);" for="">Chave Pix</label>
                                    <input style="background-color: #323637;" v-model="withdraw.pix_key"
                                   v-maska
                                   data-maska="[
                                    '###.###.###-##'
                                   ]" type="text" class="input" placeholder="Digite a sua Chave pix" required>
                                </div>
<div class="mt-5 mb-3">
    <div class="flex items-center mb-4">
<!-- Marcar a caixa automaticamente e ocultá-la -->


    </div>
</div>

                            </div>

                            <div class="flex items-center justify-center w-full mt-5">
                                <button type="submit" class="w-full ui-button-blue">
                                    <span class="text-sm font-semibold uppercase">{{ $t('SACAR') }}</span>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div v-if="isLoading" role="status" class="absolute -translate-x-1/2 -translate-y-1/2 top-2/4 left-1/2">
                        <i class="fa-duotone fa-spinner-third fa-spin" style="font-size: 45px;--fa-primary-color: var(--ci-primary-color); --fa-secondary-color: #000000;"></i>
                        <span class="sr-only">{{ $t('Loading') }}...</span>
                    </div>
                </div>
            </div>
        </div>
    </BaseLayout>
</template>


<script>

import {RouterLink, useRouter} from "vue-router";
import BaseLayout from "@/Layouts/BaseLayout.vue";
import WalletSideMenu from "@/Pages/Profile/Components/WalletSideMenu.vue";
import HttpApi from "@/Services/HttpApi.js";
import {useToast} from "vue-toastification";
import {useSettingStore} from "@/Stores/SettingStore.js";

export default {
    props: [],
    components: {WalletSideMenu, BaseLayout, RouterLink},
    data() {
        return {
            isLoading: false,
            setting: null,
            wallet: null,
            withdraw: {
                name: '',
                pix_key: '',
                pix_type: '',
                amount: '',
                type: 'pix',
                currency: '',
                symbol: '',
                accept_terms: true
            },
            withdraw_deposit: {
                name: '',
                bank_info: '',
                amount: '',
                type: 'bank',
                currency: '',
                symbol: '',
                accept_terms: true
            },
        }
    },
    setup(props) {
        const router = useRouter();
        return {
            router
        };
    },
    computed: {},
    mounted() {
        window.scrollTo(0, 0);
    },
    methods: {
        setMinAmount: function() {
            this.withdraw.amount = this.setting.min_withdrawal;
        },
        setMaxAmount: function() {
            this.withdraw.amount = this.setting.max_withdrawal;
        },
        setPercentAmount: function(percent) {
            this.withdraw.amount = ( percent / 100 ) * this.wallet.balance_withdrawal;
        },
        getWallet: function() {
            const _this = this;
            const _toast = useToast();
            _this.isLoadingWallet = true;

            HttpApi.get('profile/wallet')
                .then(response => {
                    _this.wallet = response.data.wallet;

                    _this.withdraw.currency = response.data.wallet.currency;
                    _this.withdraw.symbol = response.data.wallet.symbol;

                    _this.withdraw_deposit.currency = response.data.wallet.currency;
                    _this.withdraw_deposit.symbol = response.data.wallet.symbol;

                    _this.isLoadingWallet = false;
                })
                .catch(error => {
                    const _this = this;
                    Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                        _toast.error(`${value}`);
                    });
                    _this.isLoadingWallet = false;
                });
        },
        getSetting: function() {
            const _this = this;
            const settingStore = useSettingStore();
            const settingData = settingStore.setting;

            if(settingData) {
                _this.setting                   = settingData;
                _this.withdraw.amount           = settingData.min_withdrawal;
                _this.withdraw_deposit.amount   = settingData.min_withdrawal;
            }

            _this.isLoading                 = false;
        },
        submitWithdrawBank: function(event) {
            const _this = this;
            const _toast = useToast();
            _this.isLoading = true;

            HttpApi.post('wallet/withdraw/request', _this.withdraw_deposit).then(response => {
                _this.isLoading = false;
                _this.withdraw_deposit = {
                    name: '',
                    bank_info: '',
                    amount: '',
                    type: '',
                    accept_terms: true
                }

                _this.router.push({ name: 'profileTransactions' });
                _toast.success(response.data.message);
            }).catch(error => {
                Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                    _toast.error(`${value}`);
                });
                _this.isLoading = false;
            });
        },
        submitWithdraw: function(event) {
            const _this = this;
            const _toast = useToast();
            _this.isLoading = true;

            HttpApi.post('wallet/withdraw/request', _this.withdraw).then(response => {
                _this.isLoading = false;
                _this.withdraw = {
                    name: '',
                    pix_key: '',
                    pix_type: '',
                    amount: '',
                    type: '',
                    accept_terms: true
                }

                _this.router.push({ name: 'profileTransactions' });
                _toast.success(response.data.message);
            }).catch(error => {
                Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                    _toast.error(`${value}`);
                });
                _this.isLoading = false;
            });
        }
    },
    created() {
        this.getWallet();
        this.getSetting();

    },
    watch: {},
};
</script>

<style scoped>
/* Definindo uma base com cores sólidas e simplificando o fundo */
body {
    background-color: #f8fafc; /* Cor de fundo clara */
    color: #2d3748; /* Cor de texto escuro */
}

/* Estilo para o formulário */
form {
    background-color: #ffffff; /* Cor branca para o formulário */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Estilo para o campo de valor */
input[type="text"] {
    background-color: #f0fdf4; /* Cor de fundo verde suave */

    border-radius: 8px;
    padding: 10px;
    width: 100%;
    font-size: 1rem;
}

/* Adicionando o espaçamento entre o campo de valor e as opções de min/max */
.flex.bg-white {
    margin-top: 10px;
}

/* Estilo para os botões de min/max */
button {
    background-color: #a7dc0d; /* Cor verde sólida */
    color: #ffffff;
    border: none;
    padding: 8px 12px;
    font-size: 0.875rem;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Estilo do botão ao passar o mouse */
button:hover {
    background-color: #2f855a; /* Cor verde escuro no hover */
}

/* Ajustando os botões de min/max para ficarem alinhados corretamente */
.inline-flex {
    display: flex;
    gap: 8px;
}

/* Estilo para os rótulos */
label {
    color: #2d3748; /* Cor de texto escuro */
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 8px;
}

/* Estilo para as opções de checkbox */
input[type="checkbox"] {
    accent-color: #a7dc0d; /* Cor verde sólida no checkbox */
}

/* Ajustando o layout da seção de valor e as informações do saldo */
.flex.justify-between {
    margin-top: -10px;
    font-size: 0.875rem;
    color: #4a5568; /* Cor cinza claro */
}

/* Estilo do botão de envio */
.ui-button-blue {
    background-color: #a7dc0d; /* Cor verde sólida */
    color: #ffffff;
    padding: 12px;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    text-transform: uppercase;
    width: 100%;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Estilo do botão de envio ao passar o mouse */
.ui-button-blue:hover {
    background-color: #2f855a; /* Cor verde escuro no hover */
}

/* Ajustando o layout geral do componente */
.flex.items-center {
    align-items: center;
}

/* Estilo para o carregamento */
[role="status"] {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 45px;
    color: #a7dc0d; /* Cor verde sólida */
}

/* Adicionando espaçamento e alinhamento adequado aos elementos */
.mt-5 {
    margin-top: 20px;
}

.mb-3 {
    margin-bottom: 12px;
}

/* Ajustando os inputs para ficarem mais consistentes */
.input {
    padding: 10px;
    font-size: 1rem;
    border-radius: 8px;
    background-color: #f9fafb;
    width: 100%;
}

/* Ajustando os inputs de texto para manter um estilo uniforme */
input[type="text"]:focus {
    border-color: #a7dc0d; /* Borda verde ao focar */
    outline: none;
}

/* Garantindo que a coluna e os elementos fiquem bem distribuídos */
.col-span-2 {
    width: 100%;
}
.image-container {
    display: block; /* Garante que as imagens sejam empilhadas */
    width: 100%; /* Garante que o contêiner ocupe 100% do espaço disponível */
    text-align: center; /* Centraliza as imagens horizontalmente */
}

.logo-image {
    width: 125%; /* Faz a logo ocupar 110% da largura do contêiner */
    height: auto;
    margin-left: -12%; /* Ajusta para centralizar a logo e não cortá-la à esquerda */
}
img, video {
    max-width: 125%;
    height: auto;
    margin-left: 0%;
}
.pix-image {
    margin-top: 20px; /* Ajusta o espaçamento entre as imagens */
    height: auto; /* Mantém a proporção da imagem */
}
/* Estilos para os textos */
.text-container {
    margin-top: 0px;
}
.text-left-container {
    margin-top: 10px;
    display: flex; /* Flexbox para alinhar o ícone e texto horizontalmente */
    align-items: center; /* Alinha ícone e texto verticalmente no centro */
    justify-content: flex-start; /* Garante que os itens fiquem à esquerda */
}
/* Texto em negrito e branco (Solicitar Saque) */
.text-bold {
    font-weight: bold;
    color: white;
}

/* Texto em cinza claro (Retire saldo da sua conta) */
.text-light {
    color: #f0f0f0; /* Cor cinza quase branco */
}

/* Estilos para o ícone da seta (opcional) */
.fas.fa-arrow-left {
    margin-right: 8px; /* Ajusta o espaçamento entre a seta e o texto */
}
blockquote,  p {
    margin: 10px;
}


</style>
