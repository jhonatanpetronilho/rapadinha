<style>
    .item-sombra {
            position: relative;

        }

        .item-sombra::after {
            content: "";
            position: absolute;
            bottom: 0;
            right: 0;
            width: 50px; /* Largura da sombra */
            height: 50px;
            background: linear-gradient(to right, rgba(240, 240, 240, 0), #323637e7); /* Gradiente de transparência */


        }
    #placeholder-input::placeholder {
        color: white;
    }
    .texto-valor {
        font-size: 15px;
    }
    @media (max-width:768px) {
        .loading-mobile-qr {
            margin-top: 30vh;
        }
    }
    @media (max-width:600px) {
        .texto-valor {
            font-size: 12px;
        }

    }
</style>

<template>



        <div v-if="paymentType === 'stripe' && publishableKey && setting && setting.stripe_is_enable" class="p-4">
            <stripe-checkout
                ref="checkoutRef"
                :pk="publishableKey"
                :sessionId="sessionId"
            />
            <div class="flex w-full mt-3 mb-3">
                <div class="mr-2 w-36">
                    <label for="currency" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('Currency') }}</label>
                    <select id="currency" v-model="currency" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <option value="USD">$ {{ $t('Dollar') }}</option>
                        <option value="BRL">R$ {{ $t('Real') }}</option>
                    </select>
                </div>
                <div class="w-full">
                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('Amount') }}</label>
                    <input type="number"
                           v-model="amount"
                           class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                           :min="setting.min_deposit"
                           :max="setting.max_deposit"
                           :placeholder="$t('0,00')"
                           required
                    >
                </div>
            </div>

            <button :disabled="!sessionId" @click.prevent="checkoutStripe" class="w-full rounded ui-button-blue">{{ $t('Pay With Stripe') }}</button>
        </div>
        <div v-if="setting && paymentType === 'pix' && (setting.suitpay_is_enable || setting.bspay_is_enable || setting.digitopay_is_enable)">
            <div v-if="showPixQRCode && wallet" class="flex flex-col ">
                <div class="w-full">
                    <div style="display: flex;justify-content: center;margin: 0 auto;margin-bottom: 20px;width: 100%;border-top-right-radius: 8px;border-top-left-radius: 8px;">
                        <a v-if="setting" class="w-full" style="display: flex;justify-content: center;margin: 0 auto;max-height: 300px;">
                            <img style="border-top-right-radius: 8px;border-top-left-radius: 8px" :src="`/storage/`+setting.software_logo_black2" alt="" class="block" />
                        </a>



                    </div>
                    <div class="flex items-center gap-4 px-6 overflow-y-auto">
                            <div>
                                <a href="" @click.prevent="toggleModalDeposit">
                                <svg height="1em" viewBox="0 0 448 512" width="1em" xmlns="http://www.w3.org/2000/svg" class="cursor-pointer text-auth-texts/80"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z" fill="currentColor"></path></svg>
                            </a>
                            </div>
                            <div class="flex flex-col">
                                <h2 style="color: white;font-weight: 500;font-size: 18px;">Voltar</h2>
                            </div>



                        </div>
                    <div class="flex justify-center" style="margin-top: 10px;">
                        <p class="hidden text-lg md:block" style="text-align: center;font-weight: 600">Escaneie a imagem  <br>
                            para realizar o pagamento</p>
                     <p class="block text-base md:hidden" style="text-align: center;font-weight: 600">Copie o código "copia e cola"  <br>
                        abaixo para realizar o pagamento</p>

                    </div>
                </div>

                <div class="w-full px-6 overflow-y-auto">


                    <div class="flex items-center justify-center hidden p-3 qr-code-container md:block" style="max-width: 250px;margin: 0 auto;">
                        <QRCodeVue3 :value="qrcodecopypast"/>
                    </div>



                    <div @click.prevent="copyQRCode" class="relative p-4 mt-4 rounded-lg" style="text-align: center;border: 1px dashed rgba(253, 255, 255, .6);" >
                        <p class="font-bold " style="font-size: 2em;color: var(--ci-primary-color);margin-bottom: 10px">{{ state.currencyFormat(parseFloat(deposit.amount), wallet.currency) }}</p>
                        <input style="background-color: #424344;font-size: 12px;border-radius: 10px;" id="pixcopiaecola" type="text" class="w-full bg-transparent border border-gray-300 border-none rounded-md appearance-none input" v-model="qrcodecopypast">

                        <div style="position: absolute;right: 2%;top: 5%;cursor: pointer;">
                            <svg data-v-283609e4="" height="2rem" viewBox="0 0 512 512" width="2rem" xmlns="http://www.w3.org/2000/svg"><path d="M397.9,286.8c-7.2,0-13.8,2.1-19.5,5.6c-3.3-17.4-18.5-30.6-36.8-30.6c-13.6,0-25.4,7.3-32,18.1
                            c-3.9-17.4-18.5-30.6-36.8-30.6c-9.7,0-18.4,3.8-25,9.7V143c0-17.3-14-31.3-30.6-31.3c-18,0-32,14-32,31.3v252.3l-43.8-58.4
                            c-6.1-8.2-15.5-12.5-25-12.5c-16.6,0-31.3,13.3-31.3,31.3c0,6.5,2,13.1,6.3,18.7l71.3,95.1c20,26.7,51.8,42.5,85,42.5h75.1
                            c62.1,0,112.6-50.5,112.6-112.6v-75.1C435.4,303.6,418.6,286.8,397.9,286.8z M272.8,424.4c0,6.9-5.6,12.5-12.5,12.5
                            c-6.9,0-12.5-5.6-12.5-12.5v-75.1c0-6.9,5.6-12.5,12.5-12.5c6.9,0,12.5,5.6,12.5,12.5V424.4z M322.8,424.4c0,6.9-5.6,12.5-12.5,12.5
                            s-12.5-5.6-12.5-12.5v-75.1c0-6.9,5.6-12.5,12.5-12.5s12.5,5.6,12.5,12.5V424.4z M372.9,424.4c0,6.9-5.6,12.5-12.5,12.5
                            c-6.9,0-12.5-5.6-12.5-12.5v-75.1c0-6.9,5.6-12.5,12.5-12.5s12.5,5.6,12.5,12.5V424.4z" fill="currentColor" opacity="0.4"></path><path d="M260.3,336.9c-6.9,0-12.5,5.6-12.5,12.5v75.1c0,6.9,5.6,12.5,12.5,12.5c6.9,0,12.5-5.6,12.5-12.5v-75.1
                            C272.8,342.5,267.2,336.9,260.3,336.9z M310.3,336.9c-6.9,0-12.5,5.6-12.5,12.5v75.1c0,6.9,5.6,12.5,12.5,12.5s12.5-5.6,12.5-12.5
                            v-75.1C322.8,342.5,317.2,336.9,310.3,336.9z M360.4,336.9c-6.9,0-12.5,5.6-12.5,12.5v75.1c0,6.9,5.6,12.5,12.5,12.5
                            c6.9,0,12.5-5.6,12.5-12.5v-75.1C372.9,342.5,367.2,336.9,360.4,336.9z M341.8,42.1c-7.3-7.3-19.2-7.3-26.5,0l-37.5,37.5
                            c-7.3,7.3-7.3,19.2,0,26.5c4.3,3.7,9.2,5.5,13.9,5.5c4.8,0,9.6-1.8,13.3-5.5l37.5-37.5C349.8,61.3,349.8,49.5,341.8,42.1z
                            M362.8,160.4c0-10.4-8.4-18.8-18.8-18.8H291c-10.4,0-18.8,8.4-18.8,18.8c0.5,5.7,2.6,10.4,6,13.7c3.4,3.4,8.1,5.5,13.3,5.5h53.1
                            C354.9,179.6,363.3,171.3,362.8,160.4z M167.2,160.4c0-10.4-8.4-18.8-18.8-18.8H95.3c-10.4,0-18.8,8.4-18.8,18.8
                            c0.5,5.7,2.6,10.4,6,13.7c3.4,3.4,8.1,5.5,13.3,5.5h53.1C159.2,179.6,167.6,171.3,167.2,160.4z M97,68.7l37.5,37.5
                            c3.7,3.7,8.5,5.5,13.3,5.5c4.8,0,9.6-1.8,13.9-5.5c7.3-7.3,7.3-19.2,0-26.5l-37.5-37.5c-7.3-7.3-19.2-7.3-26.5,0
                            C89.7,49.5,89.7,61.3,97,68.7z M200.7,18.3v53.1c0,5.2,2.1,9.9,5.5,13.3c3.4,3.4,8.1,5.5,13.7,6c10.4,0,18.8-8.4,18.8-18.8V18.8
                            c0-10.4-8.4-18.8-18.8-18.8C209.1-0.4,200.7,8,200.7,18.3z" fill="currentColor"></path></svg>
                        </div>

                    <div class="flex items-center justify-center w-full mt-5">
                        <button @click.prevent="copyQRCode" type="button" class="w-full md:max-w-[270px] px-4 py-2" style="background-color: var(--ci-primary-opacity-color);color: var(--ci-primary-color);width: 100%;border-radius: 5px;">
                            <span style="text-wrap: nowrap;" class="text-lg md:max-w-[270px]">{{ $t('Copiar Código "copia e cola"') }}</span>
                        </button>
                    </div>
                </div>

                <div style="">
                    <div v-if="!isCompleted" class="timer" style="padding:20px 4%;">
                        <p style="color: #CC833C;font-weight: 800;font-size: 13px;"> O tempo para você pagar acaba em:</p>

                    <div class="time-display">{{ formattedTime }}</div>
                    <div class="progress-bar">

                   <div :style="{ width: progressBarWidth }"></div>
               </div>
                    </div>
                    <div v-else class="completed-message">
                    Código PIX expirado
                    </div>
                </div>

                <div v-if="showQRCode" class="flex items-center justify-center qr-code-container" style="max-width: 200px;margin: 0 auto;">
                        <QRCodeVue3 :value="qrcodecopypast"/>
                    </div>

                    <div class="flex flex-col items-center justify-center">
                    <button style="background-color: #213326;color: #22892E;padding: 5px 15px;border-radius: 5px;margin-bottom: 10px;" @click="refreshPage">Já paguei o pix</button>
                    <button style="text-align: center;" class="flex justify-center block md:hidden" @click="showQRCode = !showQRCode">
                    {{ showQRCode ? 'Ocultar QR Code' : 'Exibir QR Code' }}
                    </button>

                </div>

                </div>
            </div>
            <div v-if="!showPixQRCode">
                <div v-if="setting != null && wallet != null && isLoading === false" class="flex flex-col w-full">
                    <form action="" @submit.prevent="submitQRCode">

                        <div style="display: flex;justify-content: center;margin: 0 auto;margin-bottom: 20px;width: 100%;border-top-right-radius: 8px;border-top-left-radius: 8px;">
                        <a v-if="setting" class="w-full" style="display: flex;justify-content: center;margin: 0 auto;max-height: 300px;">
                            <img style="border-top-right-radius: 8px;border-top-left-radius: 8px" :src="`/storage/`+setting.software_logo_black2" alt="" class="block" />
                        </a>



                    </div>
                    <div class="flex items-center gap-4 px-6">
                            <div>
                                <a href="" @click.prevent="toggleModalDeposit">
                                <svg height="1em" viewBox="0 0 448 512" width="1em" xmlns="http://www.w3.org/2000/svg" class="cursor-pointer text-auth-texts/80"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z" fill="currentColor"></path></svg>
                            </a>
                            </div>
                            <div class="flex flex-col">
                                <h2 style="color: white;font-weight: bold;font-size: 20px;">Depositar</h2>
                                <p style="font-size: 14px;opacity: .7;">Adicione saldo à sua conta</p>
                            </div>
                        </div>
                        <div class="mx-6" style="display: flex; gap: 5px; justify-content: flex-start; align-items: center;">
                        <div
                        v-if="setting.suitpay_is_enable"
                            class="p-3 px-6 mt-4 mb-4 suit-hover gateway-selected"
                            :class="{'gateway-selected-active': paymentGateway === 'suitpay'}"
                            @click="setPaymentMethod('pix', 'suitpay')"
                        >
                            <img  src="../../../../public/assets/images/suitpayLogo.png" alt="Suitpay">
                        </div>
                        <div
                        v-if="setting.bspay_is_enable"
                            class="p-3 px-6 mt-4 mb-4 suit-hover gateway-selected"
                            :class="{'gateway-selected-active': paymentGateway === 'bspay'}"
                            @click="setPaymentMethod('pix', 'bspay')"
                        >
                               <img  src="../../../../public/assets/images/bspayLogo.png" alt="BSPay">
                        </div>
                        <div
                        v-if="setting.digitopay_is_enable"
                        class="p-3 mb-4 px-6mt-4 suit-hover gateway-selected"
                        :class="{'gateway-selected-active': paymentGateway === 'digitopay'}"
                        @click="setPaymentMethod('pix', 'digitopay')"
                        >
                               <img  src="../../../../public/assets/images/digitopayLogo.png" alt="Digitopay">
                        </div>
                    </div>
                        <div style="background-color: #213326;border-radius: 5px;" class="px-4 py-2 mx-6 mt-3 mb-3">
                                <p class="text-xs font-semibold md:text-base" style="color: #22912F;">Depósitos acima de R$50 concorrem a 70K de<br> prêmios todos os sábados  </p>
                            </div>

                            <div class="flex items-center w-full px-6">
                                <div class="mr-4">
                                    <label style="font-size: 12px;color: #87898A;opacity: .8;font-weight: bold;" for="methodpagamento">Método de Pagamento</label>
                                    <input disabled style="padding: 7px 0px;padding-left: 10px;background-color: var(--input-primary);border-radius: 5px;opacity: .7;" id="methodpagamento" type="text" value="PIX1">


                                </div>
                                <div>
                                    <label style="font-size: 12px;color: #87898A;opacity: .8;font-weight: bold;" for="methodpagamento2">Depósito Mínimo</label>

                                    <div style="position: relative;">
                                    <input disabled style="padding: 7px 0px;padding-left: 10px;background-color: var(--input-primary);border-radius: 5px;opacity: .7;" id="methodpagamento2" type="text" value="">
                                    <p style="position: absolute;left: 6%;top: 16%;z-index: 1;opacity: .7;">R$ {{ (setting.min_deposit), wallet.currency }}</p>
                                </div>
                                </div>


                            </div>
                            <div class="px-6 mt-3">
                            <p class="text-xs text-gray-500 md:text-base" style="font-weight: 550;color: white;">Valor a ser depositado:</p>
                            <div class="flex items-center justify-between w-full py-1 rounded">
                                <div class="flex items-center w-full">

                                    <i style="position: absolute;padding-left: 20px;font-size: 14px;z-index: 2;" class="fa-solid fa-brazilian-real-sign"></i>

                                    <div style="position: absolute;right: 0;font-size: 10px;z-index: 2;padding-right: 50px;display: flex;align-items: center;font-weight: bold;gap: 3px;" >
                                        <svg style="max-width: 10px;" xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><mask id="a"><circle cx="256" cy="256" r="256" fill="#fff"></circle></mask><g mask="url(#a)"><path fill="#6da544" d="M0 0h512v512H0z"></path><path fill="#ffda44" d="M256 100.2 467.5 256 256 411.8 44.5 256z"></path><path fill="#eee" d="M174.2 221a87 87 0 0 0-7.2 36.3l162 49.8a88.5 88.5 0 0 0 14.4-34c-40.6-65.3-119.7-80.3-169.1-52z"></path><path fill="#0052b4" d="M255.7 167a89 89 0 0 0-41.9 10.6 89 89 0 0 0-39.6 43.4 181.7 181.7 0 0 1 169.1 52.2 89 89 0 0 0-9-59.4 89 89 0 0 0-78.6-46.8zM212 250.5a149 149 0 0 0-45 6.8 89 89 0 0 0 10.5 40.9 89 89 0 0 0 120.6 36.2 89 89 0 0 0 30.7-27.3A151 151 0 0 0 212 250.5z"></path></g></svg><p>BRL</p></div>

                                        <div style="position: absolute;right: 0;padding-right: 100px;z-index: 2;font-size: 12px;color: #A7F432;" v-if="deposit.amount > 0" class="text-right">
                                         + {{ state.currencyFormat(parseFloat((deposit.amount/setting.initial_bonus * 100)) + parseFloat(deposit.amount), wallet.currency) }}  Bônus
                              </div>

                                    <input id="placeholder-input" style="position: relative;padding-left: 38px;z-index: 1;background-color: #424344;font-weight: 600" type="text"
                                           v-model="deposit.amount"
                                           class="w-full py-2 text-base bg-transparent border border-gray-300 border-none rounded-md appearance-none md:text-xl"
                                           :min="setting.min_deposit"
                                           :max="setting.max_deposit"
                                           :placeholder="$t('0,00')"
                                           required
                                    >
                                </div>

                            </div>

                            <div class="mt-3 item-selected">
                            <div style="background-color: var(--ci-primary-opacity-color);" @click.prevent="setAmount(20.00)" class="item" :class="{'active' : selectedAmount === 20.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 20</button>
                                <div class="ratio">HOT</div>
                                <img v-if="selectedAmount === 20.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                            <div style="background-color: var(--ci-primary-opacity-color);" @click.prevent="setAmount(50.00)" class="item" :class="{'active' : selectedAmount === 50.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 50</button>
                                <div class="ratio">HOT</div>
                                <img v-if="selectedAmount === 50.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                            <div style="background-color: var(--ci-primary-opacity-color);" @click.prevent="setAmount(100.00)" class="item" :class="{'active' : selectedAmount === 100.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 100</button>
                                <div class="ratio" style="">HOT</div>
                                <img v-if="selectedAmount === 100.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                        </div>


                        <div class=" item-selected">
                            <div style="background-color: var(--ci-primary-opacity-color);" @click.prevent="setAmount(250.00)" class="item" :class="{'active' : selectedAmount === 250.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 250</button>
                                <div class="ratio">HOT</div>
                                <img v-if="selectedAmount === 250.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                            <div style="background-color: var(--ci-primary-opacity-color);" @click.prevent="setAmount(500.00)" class="item" :class="{'active' : selectedAmount === 500.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 500</button>
                                <div class="ratio">HOT</div>
                                <img v-if="selectedAmount === 500.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                            <div style="background-color: var(--ci-primary-opacity-color);text-shadow: 2px 1px 11px var(--ci-primary-color);" @click.prevent="setAmount(1000.00)" class="item" :class="{'active' : selectedAmount === 1000.00}">
                                <button class="ratio2" style=" color: var(--ci-primary-color);
    font-weight: 800;" type="button">{{ wallet.symbol }} 1000</button>
                                <div class="ratio">HOT</div>
                                <img v-if="selectedAmount === 1000.00" class="img-check" :src="`/assets/images/check.png`" alt="">
                            </div>
                        </div>

                        <div class="mt-5">
    <p class="text-gray-500">CPF/CNPJ</p>
    <input type="text"
           v-model="deposit.cpf"
           v-mask="'###.###.###-##'"
           @blur="validateCpf"
           class="w-full px-2 py-3 mt-2 font-sans text-sm leading-5 text-gray-600 transition-all duration-300 bg-white border-none rounded placeholder:text-gray-300 dark:text-gray-200 dark:placeholder:text-gray-500 dark:bg-gray-900 disabled:cursor-not-allowed disabled:opacity-75"
           placeholder="Digite o CPF"
           required
           :class="{'border-red-500': cpfInvalid}"
           >
    <span v-if="cpfInvalid" class="text-sm text-red-500">CPF inválido</span>
  </div>

                            <div class="flex items-center justify-center w-full mt-5">
                            <button type="submit" class="w-full p-6 mt-1" style="border-radius: 5px; color: var(--sub-text-color);
    width: auto;
    padding: 7px 12px;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    font-weight: 400;background-color: var(--ci-primary-color);padding-top: 10px;padding-bottom: 10px;">
                                <span class="text-xl" style="color: var(--sub-text-color);font-weight: 550;">DEPOSITAR</span>
                            </button>
                        </div>













                    </div>
                    </form>
                </div>

            </div>

        </div>
                <div v-if="isLoading" role="status" class="absolute flex flex-col items-center gap-3 -translate-x-1/2 -translate-y-1/2 top-2/4 left-1/2 loading-mobile-qr">
                    Gerando QR CODE..
                    <i class="fa-duotone fa-spinner-third fa-spin" style="font-size: 45px;--fa-primary-color: var(--ci-primary-color); --fa-secondary-color: #000000;"></i>

                </div>


                <div v-if="paymentType === 'stripe' && publishableKey && setting && setting.stripe_is_enable" class="p-4">
        <stripe-checkout
            ref="checkoutRef"
            :pk="publishableKey"
            :sessionId="sessionId"
        />
        <div class="flex w-full mt-3 mb-3">
            <div class="mr-2 w-36">
                <label for="currency" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('Currency') }}</label>
                <select id="currency" v-model="currency" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="USD">$ {{ $t('Dollar') }}</option>
                    <option value="BRL">R$ {{ $t('Real') }}</option>
                </select>
            </div>
            <div class="w-full">
                <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('Amount') }}</label>
                <input type="number"
                       v-model="amount"
                       class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                       :min="setting.min_deposit"
                       :max="setting.max_deposit"
                       :placeholder="$t('0,00')"
                       required
                >
            </div>
        </div>

</div>

<button @click="togglePaymentGateway" style="border-radius: 5px; color: var(--sub-text-color);
    width: auto;
    padding: 3px 3px;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    font-weight: 400;background-color: transparent;padding-top: 10px;padding-bottom: 10px;margin-left: 4%;margin-right: 4%;margin-top: 15px;"><span class="text-xl" style="color: var(--sub-text-color);font-weight: 550;">PIX Selecionado: {{ paymentGateway }}</span></button>

</template>

<!-- Estilos CSS -->
<style>
    .item-sombra {
        position: relative;
    }

    .item-sombra::after {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        width: 50px; /* Largura da sombra */
        height: 50px;
        background: linear-gradient(to right, rgba(240, 240, 240, 0), #323637e7); /* Gradiente de transparência */
    }

    #placeholder-input::placeholder {
        color: white;
    }

    .texto-valor {
        font-size: 15px;
    }

    @media (max-width: 768px) {
        .loading-mobile-qr {
            margin-top: 30vh;
        }
    }

    @media (max-width: 600px) {
        .texto-valor {
            font-size: 12px;
        }
    }
</style>

<!-- Template HTML -->




<script>
    import { useToast } from "vue-toastification";
    import HttpApi from "@/Services/HttpApi.js";
    import QRCodeVue3 from "qrcode-vue3";
    import { useAuthStore } from "@/Stores/Auth.js";
    import { StripeCheckout } from '@vue-stripe/vue-stripe';
    import { useSettingStore } from "@/Stores/SettingStore.js";
    import CountdownTimer from "@/Pages/Home/CountdownTimer.vue";

    export default {
        props: ['showMobile', 'title', 'isFull'],
        components: { QRCodeVue3, StripeCheckout, CountdownTimer },
        data() {
            return {
                showQRCode: false, // Controla a visibilidade da div com o QR Code
                totalTime: 5 * 60, // 5 minutos em segundos
                timeRemaining: 5 * 60,
                intervalId: null,
                isCompleted: false,
                isModalOpen: true,
                isLoading: false,
                minutes: 15,
                seconds: 0,
                timer: null,
                setting: null,
                cpfInvalid: false,  // Controla o estado de CPF inválido
                wallet: null,
                deposit: {
                    amount: '',
                    cpf: '',
                    gateway: '',
                    accept_bonus: true
                },
                selectedAmount: 0,
                showPixQRCode: false,
                qrcodecopypast: '',
                idTransaction: '',
                intervalId: null,
                paymentType: null,

                /// stripe
                elementsOptions: {
                    appearance: {}, // appearance options
                },
                confirmParams: {
                    return_url: null, // success url
                },
                successURL: null,
                cancelURL: null,
                amount: null,
                currency: null,
                publishableKey: null,
                sessionId: null,
                paymentGateway: 'suitpay', // Gateway inicial é Suitpay
                logoDefault: '',
            }
        },
        setup(props) {
            return {};
        },
        computed: {
            progressBarWidth() {
                const percentage = (this.timeRemaining / this.totalTime) * 100;
                return `${percentage}%`;
            },
            formattedTime() {
                const minutes = Math.floor(this.timeRemaining / 60);
                const seconds = this.timeRemaining % 60;
                return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            },
            isAuthenticated() {
                const authStore = useAuthStore();
                return authStore.isAuth;
            },
        },
        mounted() {
            const { setting, getSettingData } = useSettingStore();
            this.setting = getSettingData();
                this.setPaymentMethod('pix', setting.default_gateway);

            // Iniciar o cronômetro
            this.startTimer();
        },
        beforeUnmount() {
            clearInterval(this.intervalId);
            clearInterval(this.timer);
            this.paymentType = null;
        },
        methods: {
              // Função de validação do CPF
    validateCpf() {
      this.cpfInvalid = !this.isCpfValid(this.deposit.cpf);
    },

    // Função que valida se o CPF é verdadeiro
    isCpfValid(cpf) {
      cpf = cpf.replace(/[^\d]+/g, ''); // Remove qualquer caractere não numérico

      if (cpf.length !== 11) return false; // CPF deve ter 11 dígitos

      // Verifica CPF inválido com todos os dígitos iguais (ex: 111.111.111-11)
      if (/^(\d)\1{10}$/.test(cpf)) return false;

      // Valida o primeiro dígito
      let sum = 0;
      for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
      }
      let remainder = sum % 11;
      let firstDigit = remainder < 2 ? 0 : 11 - remainder;
      if (parseInt(cpf.charAt(9)) !== firstDigit) return false;

      // Valida o segundo dígito
      sum = 0;
      for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
      }
      remainder = sum % 11;
      let secondDigit = remainder < 2 ? 0 : 11 - remainder;
      if (parseInt(cpf.charAt(10)) !== secondDigit) return false;

      return true;
    },

            refreshPage() {
                window.location.reload();
            },
            startTimer() {
                this.intervalId = setInterval(() => {
                    if (this.timeRemaining > 0) {
                        this.timeRemaining -= 1;
                    } else {
                        this.isCompleted = true;
                        clearInterval(this.intervalId);
                    }
                }, 1000); // Atualiza o cronômetro a cada 1 segundo
            },
            closeModal() {
                this.isModalOpen = false;
            },
            getSession: function () {
                const _this = this;
                HttpApi.post('stripe/session', { amount: _this.amount, currency: _this.currency }).then(response => {
                    if (response.data.id) {
                        _this.sessionId = response.data.id;
                    }
                }).catch(error => { });
            },
            checkoutStripe: function () {
                const _toast = useToast();
                if (this.amount <= 0 || this.amount === '') {
                    _toast.error('Você precisa digitar um valor');
                    return;
                }

                this.$refs.checkoutRef.redirectToCheckout();
            },
            getPublicKeyStripe: function () {
                const _this = this;
                HttpApi.post('stripe/publickey', {}).then(response => {
                    _this.$nextTick(() => {
                        _this.publishableKey = response.data.stripe_public_key;
                        _this.elementsOptions.clientSecret = response.data.stripe_secret_key;
                        _this.confirmParams.return_url = response.data.successURL;
                    });
                }).catch(error => { });
            },
            setPaymentMethod: function (type, gateway) {
                if (type === 'stripe') {
                    this.getPublicKeyStripe();
                }
                this.paymentType = type;
                this.paymentGateway = gateway;
            },
            submitQRCode: function(event) {
                const _this = this;
                const _toast = useToast();
                if(_this.deposit.amount === '' || _this.deposit.amount === undefined) {
                    _toast.error(_this.$t('You need to enter a value'));
                    return;
                }

                if(_this.deposit.cpf === '' || _this.deposit.cpf === undefined) {
                    _toast.error(_this.$t('Do you need to enter your CPF or CNPJ'));
                    return;
                }

                if(parseFloat(_this.deposit.amount) < parseFloat(_this.setting.min_deposit)) {
                    _toast.error('O valor mínimo de depósito é de '+ _this.setting.min_deposit);
                    return;
                }

                if(parseFloat(_this.deposit.amount) > parseFloat(_this.setting.max_deposit)) {
                    _toast.error('O valor máximo de depósito é de '+ _this.setting.min_deposit);
                    return;
                }

                _this.deposit.paymentType = _this.paymentType;
                _this.deposit.gateway = _this.paymentGateway;

                _this.isLoading = true;
                HttpApi.post('wallet/deposit/payment', _this.deposit).then(response => {
                    _this.showPixQRCode = true;
                    _this.isLoading = false;

                    _this.idTransaction = response.data.idTransaction;
                    _this.qrcodecopypast = response.data.qrcode;

                    _this.intervalId = setInterval(function () {
                        _this.checkTransactions(_this.idTransaction);
                    }, 5000);

                }).catch(error => {
                    Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                        _toast.error(`${value}`);
                    });
                    _this.showPixQRCode = false;
                    _this.isLoading = false;
                });
            },
            checkTransactions: function(idTransaction) {
                const _this = this;
                const _toast = useToast();

                HttpApi.post(_this.paymentGateway+'/consult-status-transaction', { idTransaction: idTransaction }).then(response => {
                    _toast.success('Pedido concluído com sucesso');
                    clearInterval(_this.intervalId);

                    // Inclui o valor do depósito na URL como parâmetro
                    const depositValue = _this.deposit.amount;
                    _this.$router.push({
                        path: '/pagamentoconcluido',
                        query: { value: depositValue }
                    });
                }).catch(error => {
                    Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                        // _toast.error(`${value}`);
                    });
                });
            },
            copyQRCode: function(event) {
                const _toast = useToast();
                var inputElement = document.getElementById("pixcopiaecola");
                inputElement.select();
                inputElement.setSelectionRange(0, 99999);  // Para dispositivos móveis

                // Copia o conteúdo para a área de transferência
                document.execCommand("copy");
                _toast.success('Pix Copiado com sucesso');
            },
            setAmount: function (amount) {
                this.deposit.amount = amount;
                this.selectedAmount = amount;
            },
            getWallet: function () {
                const _this = this;
                const _toast = useToast();
                _this.isLoadingWallet = true;

                HttpApi.get('profile/wallet')
                    .then(response => {
                        _this.wallet = response.data.wallet;
                        _this.currency = response.data.wallet.currency;
                        _this.isLoadingWallet = false;
                    })
                    .catch(error => {
                        const _this = this;
                        Object.entries(JSON.parse(error.request.responseText)).forEach(([key, value]) => {
                            _toast.error(`${value}`);
                        });
                        _this.isLoadingWallet = false;
                    });
            },
            getSetting: function () {
                const _this = this;
                const settingStore = useSettingStore();
                const settingData = settingStore.setting;

                if (settingData) {
                    _this.setting = settingData;
                    _this.amount = settingData.max_deposit;

                    if (_this.paymentType === 'stripe' && settingData.stripe_is_enable) {
                        _this.getSession();
                    }
                }
            },

            // Alterna entre os gateways
            togglePaymentGateway: function () {
                this.paymentGateway = this.paymentGateway === 'suitpay' ? 'bspay' : 'suitpay';
                this.setPaymentMethod('pix', this.paymentGateway);
            }
        },
        created() {
            if(this.isAuthenticated) {
                this.getWallet();
                this.getSetting();
            }
        },
        watch: {
            amount(oldValue, newValue) {
                if (this.paymentType === 'stripe') {
                    this.getSession();
                    this.currency = 'USD';
                }

            },
            currency(oldValue, newValue) {
                if (this.paymentType === 'stripe') {
                    this.getSession();
                }
            }
        },
    };
</script>

<style scoped>
.timer {
    text-align: start;
}
.progress-bar {
    padding: 0px 6%;
    width: 100%;
    background-color: #323637;
    height: 4px;
    margin-bottom: 10px;
    position: relative;
    border-radius: 20px;
}
.progress-bar > div {
    height: 100%;
    background-color: #82A81B;
    position: absolute;
    top: 0;
    left: 0;
    transition: width 0.5s;
    border-radius: 20px;
}
.time-display {
    font-size: 24px;
    font-weight: bold;
}
.completed-message {
    padding: 40px 0;
    font-size: 22px;
    color: #C13A5C;
    text-align: center;
    font-weight: bold;
}
.gateway-selected {
    cursor: pointer;
    border-radius: 8px;
    border: 1px solid var(--ci-primary-color);
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #2E3131;
    max-height: 40px;
}
.gateway-selected>img {
    max-height: 20px;
    height: auto;
    filter: drop-shadow(0px 0px 1px rgb(54, 54, 54)) drop-shadow(0px 0px 1px rgb(39, 39, 39));
}
.gateway-selected-active {
    border-color: #b0f000;
    background-color: var(--ci-primary-color);
    color: black;
}
</style>
